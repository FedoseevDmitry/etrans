Project <a href="https://fedoseevdmitry.github.io/etrans/">"E-Trans"</a> Intensive by <a href="https://methed.ru/">MethEd</a>

<ul>ToDo:
  <li><s>Markup</s></li>
  <li><s>Styles</s></li>
  <li>Adaptive</li>
  <li>Interactive</li>
</ul>